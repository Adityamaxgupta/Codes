import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';



import { HttpClientModule } from '@angular/common/http';

import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RechargeComponent } from './RecComponent/recharge.component';
import { RechargeService } from './Services/rechargeService';
import { RechargeDetailComponent } from './RechDetailComponent/rechargedetail.component';
import { RechargePipe } from './Pipe/recharge.pipe';


@NgModule({
  declarations: [
    AppComponent,
   
    RechargeComponent,
    RechargeDetailComponent,
    RechargePipe
    
    

  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule
  
  ],
  providers: [RechargeService],
  bootstrap: [AppComponent]
})
export class AppModule { }
