import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { RechargeComponent } from './RecComponent/recharge.component';
import { RechargeDetailComponent } from './RechDetailComponent/rechargedetail.component';

const routes: Routes = [

  {path:'',component:RechargeComponent},
  {path:'getAll',component:RechargeComponent},
  {path:'getFilter',component:RechargeDetailComponent},
  

]


@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
