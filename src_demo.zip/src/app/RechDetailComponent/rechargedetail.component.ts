import { OnInit, Component } from '@angular/core';
import { IRecharge } from '../Models/RechargeModel';
import { RechargeService } from '../Services/rechargeService';
import { FormBuilder, FormGroup } from '@angular/forms';
@Component({
    selector:'app-details',
    templateUrl:'rechargedetail.component.html'
})
export class RechargeDetailComponent implements OnInit{
    details:IRecharge[];
    submitted:boolean=false;
   
    ngOnInit(): void {
        
    }
    constructor(private recservice:RechargeService,private formBuilder:FormBuilder){

    }

    onSubmit(){
        this.submitted=true;
        this.recservice.getDetails().subscribe(data=>{
            this.details=data;
        })
    }

}