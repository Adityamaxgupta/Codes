import { OnInit, Component } from '@angular/core';
import { RechargeService } from '../Services/rechargeService';
import { IRecharge } from '../Models/RechargeModel';

@Component({
    selector:"app-recharge",
    templateUrl:'recharge.component.html'
})
export class RechargeComponent implements OnInit{
    details:IRecharge[];
    ngOnInit(): void {

        this.getAll();
    }

    constructor(private recservice:RechargeService){

    }

    getAll(){
this.recservice.getDetails().subscribe(data=>{
    this.details=data;
});
    }

}