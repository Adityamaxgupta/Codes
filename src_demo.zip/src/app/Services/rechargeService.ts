import { Injectable, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { IRecharge } from '../Models/RechargeModel';

@Injectable()
export class RechargeService implements OnInit{

    url:string="http://localhost:51620/Api/Recharge/GetDetails";
    ngOnInit(): void {
       this.getDetails();
    }
    constructor(private _http:HttpClient){

    }

    getDetails(){

         return this._http.get<IRecharge[]>(this.url);

    }

}