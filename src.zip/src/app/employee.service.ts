import {Injectable} from '@angular/core';
import {HttpClient} from '@angular/common/http';
import { IEmployee } from './employee';
// import 'rxjs/add/operator/take';
// import 'rxjs/add/operator/concatMap';
// import 'rxjs/add/operator/switchMap';

import { Observable } from 'rxjs';
import { of } from 'rxjs';

//import {Observable} from 'rxjs/Observable';

@Injectable()
export class EmployeeService{

private _url:string = "/assets/data/employees.json";
constructor(private http:HttpClient)
{

};

getEmployees():Observable<IEmployee[]>
{
return this.http.get<IEmployee[]>(this._url);
}
}

